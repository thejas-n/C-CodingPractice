#include <iostream>
#include<math.h>
using namespace std;

int main()
{
 float base,expo,power;
 cout<<"enter the value of base and expo:";
 cin>>base>>expo;

 power=pow(base,expo);

 cout<<base<<"^"<<expo<<"="<<power;
 return 0;
}
